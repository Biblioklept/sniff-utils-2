-- ORIGINAL MOD: https://modworkshop.net/mod/19568

Hooks:PostHook( CrimeSpreeTweakData, "init", "BLEH", function(self, tweak_data)
	self.crash_causes_loss = false
end)