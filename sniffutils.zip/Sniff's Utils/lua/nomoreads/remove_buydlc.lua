function MenuCallbackHandler:get_latest_dlc_locked()
	return false
end