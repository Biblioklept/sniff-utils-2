function MenuComponentManager.create_new_heists_gui()
    return
end