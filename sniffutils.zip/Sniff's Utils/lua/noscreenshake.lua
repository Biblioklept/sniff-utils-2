PlayerCamera.play_shaker = function(self) return 0 end
