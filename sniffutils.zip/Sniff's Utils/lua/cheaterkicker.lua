Hooks:PostHook(NetworkPeer, "set_ip_verified", "cheaterz_go_to_hell_haha", function(self, state)

	DelayedCalls:Add( "cheaterz_go_to_hell_d", 2, function()
		local user = Steam:user(self:ip())
		if user and user:rich_presence("is_modded") == "1" or self:is_modded() then
			managers.chat:feed_system_message(1, self:name() .. " HAS MODS! Checking...")
			for i, mod in ipairs(self:synced_mods()) do
				local mod_mini = string.lower(mod.name)	
				local kick_on = {}
				local potential_hax = {}
				local prob_not_clean = nil

				kick_on = {
					"arsium's weapons rebalance recoil",
					"ask bot to fix the drill",
					"berserker live matters",
					"beyond cheats",
					"dlc unlocker",
					"grimm damage buff",
					"Hefty (Conformity Version)",
					"helpful converted and teammate",
					"increase your dodge while there are civilians nearby",
					"mod that removes medics actually",
					"mod that removes turrets actually",
					"multijump",
					"No Pager On Domination",
					"overkill mod",
					"p3dhack",
					"p3dhack free",
					"p3dhack free version",
					"p3dunlocker",
					"pirate perfection",
					"pirate perfection reborn trainer!",
					"pirate perfection reborn trainer! free edition",
					"pirate Perfection peborn trainer! unlocker standalone edition",
					"pocket ecm hack turret",
					"print faster",
					"reduced iframe damage",
					"selective dlc unlocker",
					"skin unlocker",
					"slot machine cheat",
					"spawn addition loots on gage package",
					"the great skin unlock",
					"unhittable armour",
					"ultimate trainer"
				}

				for _, v in pairs(kick_on) do
					if mod_mini == v then
						local identifier = "cheater_banned_" .. tostring(self:id())
						managers.ban_list:ban(identifier, self:name())
						managers.chat:feed_system_message(1, self:name() .. " has been kicked because of using the mod: " .. mod.name)
						local message_id = 0
						message_id = 6
						managers.network:session():send_to_peers("kick_peer", self:id(), message_id)
						managers.network:session():on_peer_kicked(self, self:id(), message_id)
						return
					end
				end

				potential_hax = {
					"advanced movement standalone",
					"akimbo",
					"ammo",
					"better bots",
					"bile",
					"boost",
					"buff",
					"carry stacker",
					"cheat",
					"cook",
					"damage",
					"deck",
					"dlc",
					"dodge",
					"faster",
					"god",
					"hack",
					"hefty",
					"helper",
					"meth",
					"mvp",
					"overhaul",
					"overkill mod",
					"p3d",
					"pager",
					"perk",
					"pirate",
					"print",
					"rebalance",
					"recoil",
					"rng",
					"silent assassin",
					"spawn",
					"speed",
					"stay there, bile",
					"tediore",
					"trainer",
					"unlock",
					"WeaponLib",
					"x-ray",
					"cook faster",
					"silent assassin"
				}

				for k, pc in pairs(potential_hax) do
					if string.find(mod_mini, pc) then
						log("found something!")
						managers.chat:feed_system_message(1, self:name() .. " is using a mod that can be a potential cheating mod: " .. mod.name)
						prob_not_clean = 1
					end
				end
			end

			if prob_not_clean then
				managers.chat:feed_system_message(1, self:name() .. " has a warning... Check his mods/profile manually to be sure.")
			else
				managers.chat:feed_system_message(1, self:name() .. " seems to be clean.")
			end
		else
			managers.chat:feed_system_message(1, self:name() .. " doesn't seem to have mods.")
		end
	end)
end)